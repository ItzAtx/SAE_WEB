-- Tracer l’historique des fonctions, avec la date de début et de fin, 
-- de l’employé ayant comme nom Sorton, par ordre chronologique
SELECT fonction, TO_CHAR(date_debut, 'DD/MM/YYYY') as date_debut, TO_CHAR(date_fin, 'DD/MM/YYYY') as date_fin
FROM Personnel p, Contrat c, Fonction f 
WHERE p.id_personnel = c.id_personnel AND c.id_fonction = f.id_fonction AND nom_personnel='Sorton'
ORDER BY date_debut;

-- Quels sont le(s) nom(s) de(s) soigneur(s) ayant soigné tous les animaux ?

-- 1ère façon : HAVING / GROUP BY
SELECT nom_personnel, prenom_personnel
FROM Personnel p, Soins s
WHERE p.id_personnel = s.id_personnel
GROUP BY p.id_personnel, p.nom_personnel, p.prenom_personnel
HAVING COUNT(DISTINCT s.RFID) = (SELECT COUNT(*) FROM Animal);

-- 2ème façon : 
SELECT DISTINCT nom_personnel, prenom_personnel
FROM Personnel p
WHERE NOT EXISTS (
    SELECT a.RFID FROM Animal a
    WHERE NOT EXISTS (
        SELECT * FROM Soins s
        WHERE s.id_personnel = p.id_personnel
        AND s.RFID = a.RFID
    )
);

-- 3ème façon : 
SELECT DISTINCT nom_personnel, prenom_personnel
FROM Personnel p
WHERE NOT EXISTS (
    SELECT a.RFID FROM Animal a
    MINUS
    SELECT s.RFID FROM Soins s
    WHERE s.id_personnel = p.id_personnel
);

-- Lister les soins (id_soin, date_soin, complexité) réalisés
-- entre le 05/02/2025 et le 02/03/2025, triés par complexité décroissante.

SELECT id_soin, date_soin, complexite
FROM Soins
WHERE date_soin >= TO_DATE('05022025', 'DDMMYYYY') AND date_soin <= TO_DATE('02032025', 'DDMMYYYY')
ORDER BY complexite DESC;

-- Pour chaque enclos, afficher son identifiant et le nombre d'animaux
-- qu'il contient.

SELECT e.id_enclos, COUNT(a.RFID) as NombreAnimal
FROM Enclos e, Animal a
WHERE e.id_enclos = a.id_enclos
GROUP BY e.id_enclos;

-- Quels sont les enclos qui contiennent en moyenne des animaux
-- de plus de 50 kg ? Afficher l'id de l'enclos et le poids moyen.

SELECT e.id_enclos, AVG(poids)
FROM Enclos e, Animal a
WHERE e.id_enclos = a.id_enclos
GROUP BY e.id_enclos
HAVING AVG(poids) > 50;

-- Quel est l'animal (nom) ayant le poids le plus élevé dans le zoo ?

SELECT nom_animal
FROM Animal
WHERE poids = (SELECT MAX(poids) FROM Animal);

-- Quels sont les personnels ayant prodigué des soins à plus de 3 animaux
-- différents ? Afficher leur nom et prénom.

SELECT nom_personnel, prenom_personnel
FROM Personnel p, Soins s 
WHERE p.id_personnel = s.id_personnel
GROUP BY p.id_personnel , nom_personnel, prenom_personnel
HAVING COUNT(DISTINCT RFID) > 3;

-- Quels sont les animaux (nom) qui ont reçu des soins 
-- ET qui ont consommé au moins un repas ?

SELECT DISTINCT a.nom_animal
FROM Animal a
WHERE a.RFID IN (
    SELECT s.RFID
    FROM Soins s
    INTERSECT
    SELECT c.RFID
    FROM Consomme c
);

-- Crée une vue BILAN-ANIMAL qui, pour chaque animal, affiche son nom, le nombre de soins reçus et la date du dernier soin
DROP VIEW IF EXISTS BILAN_ANIMAL;
CREATE VIEW BILAN_ANIMAL AS 
SELECT a.nom_animal, COUNT(s.id_soin) as nb_soin, MAX(s.date_soin) as dernier_soin
FROM Animal a, Soins s 
WHERE a.RFID = s.RFID
GROUP BY a.nom_animal;

-- A partir de cette vue, afficher uniquement les animaux ayant reçu plus de 3 soins, triés par date de dernier soin décroissante
SELECT nom_animal, nb_soin, dernier_soin
FROM BILAN_ANIMAL
WHERE nb_soin > 3
ORDER BY dernier_soin DESC;

-- Afficher le nom des enclos, leur surface et les réparations associés si elles existent
SELECT e.id_enclos, e.surface, r.id_reparation, r.nature_reparation
FROM ENCLOS e
LEFT JOIN REPARATION r ON e.id_enclos = r.id_enclos;

-- Afficher les prestations et les id des visiteurs qui sont associés à cette prestation
SELECT p.id_prestation, p.libelle_prestation, pa.id_visiteur
FROM PARRAINER pa
RIGHT JOIN PRESTATIONS p ON pa.id_prestation = p.id_prestation
ORDER BY p.id_prestation;

-- Afficher, sous forme de couple, les animaux dans le même enclos ainsi que l'enclos en question.
SELECT a1.RFID AS animal1, a2.RFID AS animal2, a1.id_enclos
FROM Animal a1, Animal a2
WHERE a1.id_enclos = a2.id_enclos 
  AND a1.RFID < a2.RFID;